MEASURE AR v0.6.6

Deze upgrade verandert de app van prototype naar een compactere AR-werkomgeving.

STARTSCHERM
- Welkomsscherm met Measure AR-logo
- Start AR
- Instellingen
- Standaard eenheid
- Standaard lijndikte
- Labels aan/uit

CAMERAMENU
- Compacter lettertype en kleinere knoppen
- Interne scroll
- Meten en Uitzetten worden binnen dezelfde AR-sessie gekozen
- Nieuwe lijn
- Nieuwe lijn vanaf laatste punt
- Afstand uitzetten vanaf laatste punt
- Objecten
- Actieve lijn
- Ongedaan maken
- Alles wissen
- Terug naar start

TECHNISCHE LIJNEN
- Cilinders verwijderd
- Screen-space Line2-lijnen
- Dikte 1 t/m 4
- Lijn blijft visueel strak en leesbaar

LIJNLABELS
- Naam + afstand rechtstreeks op de lijn
- Bijvoorbeeld: AB · 2,50 m
- Labels zijn via Instellingen uit te schakelen

LIJN BEWERKEN
- Open Objecten
- Selecteer bijvoorbeeld AB
- Actieve lijn verschijnt
- Nieuwe lengte invoeren
- 'Lengte aanpassen vanaf startpunt'
- A blijft staan
- B verschuift in dezelfde richting
- label en afstand worden vernieuwd

BESCHERMING
- Als eindpunt B ook aan een andere lijn hangt, wordt de lengtemodificatie voorlopig geblokkeerd
- Dit voorkomt onverwachte vervorming van verbonden geometrie

UNDO
- Recente lijncreatie en lengtewijziging kunnen ongedaan worden gemaakt

BELANGRIJKE TESTS
1. Start AR vanaf het nieuwe startscherm
2. Maak AB
3. Objecten > selecteer AB
4. Verander dikte 1/2/3/4
5. Verander lengte AB
6. Controleer dat A blijft staan en B verschuift
7. Maak B-C
8. Probeer daarna AB opnieuw te verlengen: dit moet geblokkeerd worden
9. Test Ongedaan maken
10. Wissel Meten/Uitzetten zonder AR te verlaten

PUBLICEREN
Vervang in de GitHub-repository Measure_tool alleen index.html door deze versie.
Commit naar main. GitHub Pages publiceert vervolgens automatisch.
